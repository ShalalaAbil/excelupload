<?php

include("receiver.php"); 

#echo  $count = $_POST['count'];

for($i=1;$i<$count+1; $i++){
    echo  $date = $_POST['date'.$i];
    echo  $currency = $_POST['currency'.$i];
    echo  $value = $_POST['value'.$i];
    echo "update temporary set converted='".$value."' where DATE_FORMAT( str_to_date(DATE, '%d.%m.%Y %H:%i:%s'), '%d.%m.%Y') ='".$date."' and Currency='".$currency."' ";
    $db->Update("update temporary set converted=".$value." where DATE_FORMAT( str_to_date(DATE, '%d.%m.%Y %H:%i:%s'), '%d.%m.%Y')='".$date."' and Currency='".$currency."' ");


}

 $qu="Insert into paymenttransactions 
                ( Uid, Amount, AmountUSD, Currency, CurrentDebt, CreditId, PaymentSystem, TransactionNumber, Comment,createdAt)
  select '".uniqid()."', Amount, Amount/converted,  Currency,0, agreement_id, PaymentSystem,TransactionNumber, Comment,date from temporary 
      
         ";

$db->Insert($qu);
$select= $db->Select("Select Amount, Currency, id from credits where id in (Select agreement_id from temporary ) ");

$amount=0;
foreach($select as $sel ){
    $selectt= $db->Select("Select * from paymenttransactions where creditId='".$sel['id']."' 
    ORDER BY 
 if(createdAt LIKE '%.%',DATE_FORMAT(str_to_date(createdAt, '%d.%m.%Y'), '%Y-%m-%d %H:%i:%s'),DATE_FORMAT(str_to_date(createdAt, '%d-%m-%Y %H:%i:%s'), '%Y-%m-%d %H:%i:%s'))  ");
   
    foreach($selectt as $sell ){
  
        $amount+=$sell['Amount'];
        
        $CurrentDebt=$sel['Amount']-$amount;
    
        echo "update paymenttransactions set
        CurrentDebt=".$CurrentDebt." 
        where uid='".$sell['Uid']."' "."<br>";

        $db->Update("update paymenttransactions set
        CurrentDebt=".$CurrentDebt." 
        where uid='".$sell['Uid']."' ");

    }
}


?>