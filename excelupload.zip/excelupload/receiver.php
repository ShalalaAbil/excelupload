<?php 
#include("sh.php");
#exit;
echo "fffffffff";
    include("connection.php");  
      
    

    $filename=date("Y-m-d").".txt";
    if(!file_exists("test.txt")) $myfile = fopen($filename, "w") or die("Unable to open file!");
    fwrite($myfile, "Request:ip:".$_SERVER['REMOTE_ADDR'].",");
    fwrite($myfile, "date:".date("Y-m-d H:i:s").",");
    fclose($myfile);



error_reporting(E_ERROR);


function rmdir_recursive($dir) {
    foreach(scandir($dir) as $file) {
       if ('.' === $file || '..' === $file) continue;
       if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
       else unlink("$dir/$file");
   }

   rmdir($dir);
}
$db = new DatabaseClass(
    "ip",
    "db",
    "user",
    'password'
); 

function parse_file($db) {
    
   

    $path = glob("aaa/*.xlsx");
    #print_r($path);

    $result = mysqli_query( $con, $query );

    require_once "Classes/PHPExcel.php";

    $reader= PHPExcel_IOFactory::createReaderForFile($path[0]);
    $excel_Obj = $reader->load($path[0]);
    
    //Get the last sheet in excel
    //$worksheet=$excel_Obj->getActiveSheet();
    
    //Get the first sheet in excel
    $worksheet=$excel_Obj->getSheet('0');
    
    #echo "llll".$worksheet->getCell('A3')->getValue()."ooooo".$worksheet->getCell('B4')->getValue()."pppppppp";
    
    $lastRow = $worksheet->getHighestRow();
    $colomncount = $worksheet->getHighestDataColumn();
    $colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);
    
    $basket=uniqid();
        for($row=1;$row<=$lastRow;$row++){
           
            $qu="Insert into temporary ( basket, TransactionNumber, Amount, Currency, agreement_id, PaymentSystem, Comment, date,createdAt) 
            values ('".$basket."',";
            for($col=0;$col<=$colomncount_number-1;$col++){
                $ad=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
               if( strlen($ad) == 0){
                
                    $qu .="' ', ";
                }
                else{
                    if(is_string($ad)){
                        if($col==3){

                            $ad=$db->Select("select id from credits where ContactNo='".$ad."'");
                            $qu .="'".$ad[0]['id']."',"; 
                        }
                        else{
                            $qu .="'".$ad."',"; 
                        }
                        
                    }
                    else{
                        $qu .=$ad.",";
                    }

                }
                 
            }
           
            #$qu=substr($qu, 0, -1);
            $qu = $qu."'".date('Y-m-d h:i:s')."')";
             #echo  $qu."<br>";
             
             $db->Insert($qu);  
          
        }

        #show table 
       
        $fromtemorary=$db->Select("Select a.date, a.Currency from temporary  where   group by date, currency  ");
        print_r($fromtemorary);
        $count=count($fromtemorary);

        echo "<table border='1'>

                <tr><th>currency</th><th>date</th><th>rate</th></tr>

                <form method='POST' action='action.php'>";
                    $i=0;
                    foreach($fromtemorary as $fields){ #3
                        $i++;
                        $date='date'.$i;
                        $currency='currency'.$i;
                        $value='value'.$i;
                        
                        echo "<tr>
                                <input type='hidden' id='count'  name='count'  value=$count>
                                <input type='hidden' id=$date  name=$date  value=$fields[date]>
                                <td>".$fields['date']."</td>
                                
                                <input type='hidden' id=$currency  name=$currency  value=$fields[Currency]>
                                <td>".$fields['Currency']."</td>
                                
                                <td>
                                    <input type='text' id=$value name=$value>
                                </td>
                                    
                        
                        </tr>";

                    }

                # <input hidden value='"$count' name='count'>
                # </form></td>
        
                echo "</table>
                
                    <input type='submit' value='Submit'>
                </form>";

                

#exit;
    


        #if (!unlink($targetzip))
       # { #echo "Folder is deleted successfully";
       # }else{ #echo "Folder is not deleted";
        #}

}
function currentdebt($db){
    $qu="Insert into paymenttransactions 
                       ( Uid, Amount, AmountUSD, Currency, CurrentDebt, CreditId, PaymentSystem, TransactionNumber, Comment,createdAt)
         select '".uniqid()."', Amount, Amount/converted,  Currency,
         (select CurrentDebt  from paymenttransactions as a  where date< dt and 
         creditId=agr limit 1)-Amount/converted
          , agreement_id as agr, PaymentSystem,TransactionNumber, Comment, date as dt,date from temporary
             
                ";

    #$db->Insert("insert");
   

}


function show(){
    $ad=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                $payment=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(2).$row)->getValue();
                $currency=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(3).$row)->getValue();
                $agreement_id=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(3).$row)->getValue();
                $type=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(5).$row)->getValue();
                $commnetary=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(6).$row)->getValue();
                $date=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex(6).$row)->getValue();
    #$creditid=$db->Select("Select id, currency,  from credits where contactno='".$ ."'");
                
               
    $paymnets=$db->Select("Select * from paymenttransactions where creditId='".$creditid[0]['id']."'");
    $qu="Insert into paymenttransactions ( bid, uid, customer, agreement_id, amount_azn, fin_code, currency, current_debt, amount_usd, pay_azn, pay_usd, interest, penalty, principal, payment_system, cmnt, company_name, date, senddate, transaction_number, update_status, origdate, origdebt, newdate, newdebt,login_name, login_name1, ucID, crID, srt, del, datek, datem, datec)
    values ( ";

    $qu="Insert into paymenttransactions 
                       ( Uid, Amount, AmountUSD, Currency, CurrentDebt, CreditId, PaymentSystem, TransactionNumber, Comment) 
                values ('".uniqid()."', '".$payment."', if($currency=='AZN','".$payment."',$payment*1.7), if($currency=='USD','".$payment."',0), 
                if(
$creditid[0]['currency']== $currency,(select CurrentDebt from paymenttransactions where $date> CurrentDebt order by id desc limit 1)-$payment ,
(if())
        ), '".uniqid()."',";
    
         #$db->Insert("Insert into paymenttransactions (Amount,AmountUSD,Currency,CurrentDebt,CreditId,CreatedAt,PaymentSystem,TransactionNumber,Comment) values ( )"); 

}



#echo "ok";
#var_dump($_FILES);


if($_FILES["zip_file"]["name"]) {
    $filename = $_FILES["zip_file"]["name"];
    $source = $_FILES["zip_file"]["tmp_name"];
    $type = $_FILES["zip_file"]["type"];

    $name = explode(".", $filename);
    $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
    foreach($accepted_types as $mime_type) {
        if($mime_type == $type) {
            $okay = true;
            break;
        } 
    }

    $continue = strtolower($name[1]) == 'zip' ? true : false;
    if(!$continue) {
        $message = "The file you are trying to upload is not a .zip file. Please try again.";
    }

  /* PHP current path */
  $path = dirname(__FILE__).'/';  // absolute path to the directory where zipper.php is in
  $filenoext = basename ($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
  $filenoext = basename ($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)

  $targetdir = $path . $filenoext; // target directory
   $targetzip = $path . $filename; // target zip file

  /* create directory if not exists', otherwise overwrite */
  /* target directory is same as filename without extension */

  if (is_dir($targetdir))  rmdir_recursive ( $targetdir);


  mkdir($targetdir, 0777);


  /* here it is really happening */

    if(move_uploaded_file($source, $targetzip)) {
        $zip = new ZipArchive();
        $x = $zip->open($targetzip);  // open the zip file to extract
        if ($x === true) {
            $zip->extractTo($targetdir); // place in the directory with same name  
            $zip->close();

            
        }
        $message = "Your .zip file was uploaded and unpacked.";

        parse_file($db);

    } else {    
        $message = "There was a problem with the upload. Please   again.";
    }

    #echo $message;
}




