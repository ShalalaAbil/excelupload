<?php

exit;
include("connection.php"); 

$db = new DatabaseClass(
    "ip",
    "db",
    "user",
    'password'
); 


echo "ggg";
#$fin=$_GET["finCode"];
$key= $_GET["key"];
$pin=$_GET["finCode"];


$ip="94.20.38.68";
#makejson(200,'', '',$credit['pin_code'],$credit['customer_name'],$paar);
 echo "________".$secretKey."_________";
 $secretKey=md5($pin.(md5("emanat".$ip)));
function makejson($status,$message,$key,$farr){
    $arr=[
          'status'  => $status,
          'message'  =>$message,
          'key'  =>$key,
          'response' =>$farr
          

        ];               


    echo  json_encode(array_filter($arr));

}
#makejson(200,"", "",$faar);

if(empty($pin)){
    makejson(1,"Required parameters is missing","","");

 }
 if($key!=$secretKey){
    makejson(2,"Wrong key",$secretKey,"","");

 }
try{

    $customer=$db->Select("Select agreement_id from u_works where pin_code='".$pin."'");
#print_r($customer);
}
catch(Exception $e){
    throw new Exception($e->getMessage());   
}	
 

 if ($customer == null){
    makejson(3,"Customer doesn't exist","","");
 }

 

 try{

    $credits=$db->Select("Select * from u_works where pin_code='".$pin."'");
#print_r($customer);
}
catch(Exception $e){
    throw new Exception($e->getMessage());   
}	
 

$paar=[];

#print_r($credits);

 
    $farr=[];
foreach ($credits as $key => $credit)
{
    $fin = $credit['pin_code'];
    $fullName = $credit['customer_name'];
    try
    {
        $payments=$db->Select("Select agreement_id from  u_works
         where agreement_id='".$credit['agreement_id']."'");
    }

    catch(Exception $e){
        makejson(300,'Undefined Error',"","");  
    }
   
    $rate = 1;

    $AmountUSD = 0;
     $amount = $credit['debt_sum_w_court_fee'];

    
    if ($credit['currency_code'] == "USD")
    {
        $AmountUSD = Round($credit['debt_sum_w_court_fee'] / $rate, 2);
    }

    
    if ($amount>0)
    {
        
        $parr[$key]=[
            
            'uid' =>$credit['uid'],
            'amountAZN' =>$credit['debt_sum_w_court_fee_azn'],
            'AmountUSD' =>$credit['debt_sum_w_court_fee'],
            'ContactNo' =>$credit['agreement_id'],
            'Currency' =>$credit['currency_code']
            
        ];
        
        
        
    }
    
}
$farr=[
    'fin' => $fin, 
    'fullName' => $fullName,
    'credits' => $parr
];

#print_r($farr);
makejson(200,"", "",$farr);



?>